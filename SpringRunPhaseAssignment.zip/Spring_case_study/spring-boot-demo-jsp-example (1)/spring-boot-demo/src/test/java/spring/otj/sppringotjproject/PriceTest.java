package spring.otj.sppringotjproject;

public class PriceTest {
//	private MockMvc mvc;
//
//	@Mock
//	ProductsService productService;
//	
//	@InjectMocks
//	ProductController productController;
//	
//	@Before
//	public void setup() {
//		mvc = MockMvcBuilders.standaloneSetup(productController).build();
//		MockitoAnnotations.initMocks(productController);
//	}
//	
//	@org.junit.jupiter.api.Test
//	public void testMessage() throws Exception {
////		int s = 4;
//		when(productService.getMessage("as")).thenReturn(4);
////		asserEquals(s,productService.getMessage("as"));
//		assertEquals(4, productController.getMessage("as"));
////		assertEquals(s, productService.getMessage("as"), "message");
//	}
//	
//	private static final double DELTA = 1e-15;
//	
//	// Test Case Should Pass
//	// Controller level JUnit Testing status code and response content
////	@Test
////	public void testCaseGetProductPrice() throws Exception {
////		Products products = new Products();
////		long dp = 60000;
////		when(productService.getProductPrice("2")).thenReturn(dp);
////		long d = productService.getProductPrice("2");
//////		assertEquals(dp, d);
//////		assertEquals(dp, productController.getProductPrice("2"));
//////		Assert.assertTrue(Math.abs(d-dp) == 0);
//////		assertEquals(dp, d, DELTA );
////	}

}
